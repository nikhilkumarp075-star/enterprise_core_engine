-- Lean 4 practice: propositional logic
namespace Portfolio

theorem and_swap (p q : Prop) : p ∧ q → q ∧ p := by
  intro h
  exact ⟨h.right, h.left⟩

theorem implication_chain (p q r : Prop) :
    (p → q) → (q → r) → p → r := by
  intro hpq hqr hp
  exact hqr (hpq hp)

theorem or_swap (p q : Prop) : p ∨ q → q ∨ p := by
  intro h
  cases h with
  | inl hp => exact Or.inr hp
  | inr hq => exact Or.inl hq

theorem not_both (p : Prop) : ¬ (p ∧ ¬ p) := by
  intro h
  exact h.right h.left

end Portfolio
