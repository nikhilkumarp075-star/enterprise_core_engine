-- Lean 4 practice: elementary algebra and equality
namespace Portfolio

theorem add_zero_right (n : Nat) : n + 0 = n := by
  rfl

theorem zero_add_left (n : Nat) : 0 + n = n := by
  simp

theorem add_commute (a b : Nat) : a + b = b + a := by
  omega

theorem add_associate (a b c : Nat) : (a + b) + c = a + (b + c) := by
  omega

theorem double_is_sum (n : Nat) : n + n = 2 * n := by
  omega

end Portfolio
