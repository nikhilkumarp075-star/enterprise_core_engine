-- Lean 4 practice: natural-number inequalities and divisibility
import Mathlib

namespace Portfolio

theorem sum_nonnegative (a b : Nat) : 0 ≤ a + b := by
  omega

theorem add_preserves_le (a b c : Nat) (h : a ≤ b) : a + c ≤ b + c := by
  omega

theorem square_nonnegative (n : Int) : 0 ≤ n * n := by
  positivity

theorem even_double (n : Nat) : Even (2 * n) := by
  exact ⟨n, by omega⟩

theorem divisible_by_three (n : Nat) : 3 ∣ 3 * n := by
  exact ⟨n, rfl⟩

end Portfolio
